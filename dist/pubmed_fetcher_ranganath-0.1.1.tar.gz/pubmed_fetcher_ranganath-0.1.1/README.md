# PubMed Paper Fetcher

A Python command-line tool to fetch research papers from PubMed that include at least one author affiliated with a **pharmaceutical or biotech** company.

---

## 🧠 Features

- 🔍 Search using full PubMed query syntax
- 🏢 Filters **non-academic** authors by affiliation
- 🧪 Detects **company names** from affiliation heuristics
- 📧 Extracts corresponding author **email**
- 📦 Exports to CSV or prints to console
- 🐍 Fully typed and modular Python
- 🛠 CLI command via `poetry run get-papers-list`

---

## 🚀 Installation

```bash
git clone https://github.com/<your-username>/pubmed-fetcher.git
cd pubmed-fetcher
poetry install
